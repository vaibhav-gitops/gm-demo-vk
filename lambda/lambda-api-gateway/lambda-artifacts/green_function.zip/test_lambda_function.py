# lambda_function.py.py

import json

def lambda_handler(event, context):
    """
    Sample Lambda function that returns input event data.
    """
    # Print event for debugging
    print(f"Received event: {json.dumps(event)}")

    # Return a success message with the event data
    return {
        'statusCode': 200,
        'body': json.dumps({
            'message': 'Green from Lambda!',
            'event': event
        })
    }
